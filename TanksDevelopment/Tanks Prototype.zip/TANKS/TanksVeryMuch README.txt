//    TANKS VERY MUCH !
// GHS Game -- Spring 2020
// C++, SFML, OpenGL, GLSL

Tank Prototype
(latest addition: tank pool)
4.19.2020

Controls:
Move with arrow keys
Turret left = [
Turret right = ]
Fire = \

Music Control:
Space = silent loop
P = pause loop
G = game loop
M = menu loop
I = 'iron' sting
S = 'snare' sting
