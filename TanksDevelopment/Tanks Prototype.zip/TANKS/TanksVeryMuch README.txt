//    TANKS VERY MUCH !
// GHS Game -- Spring 2020
// C++, SFML, OpenGL, GLSL

Tank Prototype
(latest addition: spatial sound)
5.22.2020

Controls:
Move with arrow keys
Turret left = [
Turret right = ]
Fire = \

Debug Control:
~ = display debug stats

Troubleshooting:
* If nothing happens when
double-clicking the .exe,
please re-install. The 
application is designed to 
stop if audio or images are
missing.